import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/geo.dart';
import '../core/models.dart';
import '../state/app_state.dart';

/// Przeliczenie lat/lon <-> piksele. Uzywane i przez painter, i przez obsluge dotyku.
class MapTransform {
  final LocalProjection proj;
  final double scale; // piksele na metr
  final Offset origin; // srodek ekranu
  final double panX;
  final double panY;

  MapTransform({
    required this.proj,
    required this.scale,
    required this.origin,
    this.panX = 0,
    this.panY = 0,
  });

  Offset toScreen(double lat, double lon) {
    final xy = proj.toXY(lat, lon);
    return Offset(
      origin.dx + xy[0] * scale + panX,
      origin.dy - xy[1] * scale + panY,
    );
  }

  List<double> toLatLon(Offset p) {
    final x = (p.dx - origin.dx - panX) / scale;
    final y = -(p.dy - origin.dy - panY) / scale;
    return proj.toLatLon(x, y);
  }
}

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  double _zoom = 1.0; // mnoznik wzgledem auto-dopasowania
  Offset _pan = Offset.zero;
  Offset _panStart = Offset.zero;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return Column(
      children: [
        Expanded(
          child: LayoutBuilder(builder: (context, box) {
            final size = Size(box.maxWidth, box.maxHeight);
            final tr = _buildTransform(app, size);

            return GestureDetector(
              onScaleStart: (d) => _panStart = _pan - d.localFocalPoint,
              onScaleUpdate: (d) {
                setState(() {
                  if (d.pointerCount > 1) {
                    _zoom = (_zoom * (1 + (d.scale - 1) * 0.15))
                        .clamp(0.2, 20.0);
                  }
                  _pan = _panStart + d.localFocalPoint;
                });
              },
              onLongPressStart: (d) {
                final ll = tr.toLatLon(d.localPosition);
                _askWaypointName(context, app, ll[0], ll[1]);
              },
              child: Container(
                margin: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: const Color(0xFF071021),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white10),
                ),
                clipBehavior: Clip.antiAlias,
                child: CustomPaint(
                  painter: MapPainter(app: app, transform: tr),
                  child: const SizedBox.expand(),
                ),
              ),
            );
          }),
        ),
        _ApBar(app: app),
        _buttons(context, app),
      ],
    );
  }

  MapTransform _buildTransform(AppState app, Size size) {
    // srodek: pozycja lodki, a jesli brak - pierwszy waypoint / HOME
    double cLat, cLon;
    if (app.telemetry.gps.valid) {
      cLat = app.telemetry.gps.lat;
      cLon = app.telemetry.gps.lon;
    } else if (app.autopilot.homeLat != null) {
      cLat = app.autopilot.homeLat!;
      cLon = app.autopilot.homeLon!;
    } else if (app.waypoints.isNotEmpty) {
      cLat = app.waypoints.first.lat;
      cLon = app.waypoints.first.lon;
    } else {
      cLat = 50.0380;
      cLon = 15.7790;
    }

    final proj = LocalProjection(cLat, cLon);

    // auto-dopasowanie: najdalszy istotny punkt
    var maxR = 60.0;
    void consider(double lat, double lon) {
      final d = distanceM(cLat, cLon, lat, lon);
      if (d > maxR) maxR = d;
    }

    for (final w in app.waypoints) {
      consider(w.lat, w.lon);
    }
    for (final w in app.autopilot.route) {
      consider(w.lat, w.lon);
    }
    if (app.autopilot.homeLat != null) {
      consider(app.autopilot.homeLat!, app.autopilot.homeLon!);
    }
    final step = math.max(1, app.track.length ~/ 400);
    for (var i = 0; i < app.track.length; i += step) {
      consider(app.track[i].lat, app.track[i].lon);
    }

    final fit = (math.min(size.width, size.height) / 2 - 30) / maxR;
    return MapTransform(
      proj: proj,
      scale: fit * _zoom,
      origin: Offset(size.width / 2, size.height / 2),
      panX: _pan.dx,
      panY: _pan.dy,
    );
  }

  Widget _buttons(BuildContext context, AppState app) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
      child: Row(children: [
        _btn(Icons.add_location_alt, 'Punkt tu', () => app.addWaypointHere()),
        _btn(Icons.home_outlined, 'Ustaw HOME', app.setHomeHere),
        _btn(Icons.route, 'Start trasy', app.runRoute),
        _btn(Icons.keyboard_return, 'Powrót', app.returnHome),
        _btn(Icons.grid_on, 'Mapowanie', () => _surveyDialog(context, app)),
        _btn(Icons.list, 'Punkty', () => _waypointList(context, app)),
        _btn(Icons.ios_share, 'Eksport CSV', () async {
          final f = await app.exportCsv();
          await Share.shareXFiles([XFile(f.path)],
              text: 'Pomiary głębokości TF650');
        }),
        _btn(Icons.layers_clear, 'Wyczyść ślad', app.clearTrack),
      ]),
    );
  }

  Widget _btn(IconData icon, String label, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: OutlinedButton.icon(
          onPressed: onTap,
          icon: Icon(icon, size: 16),
          label: Text(label, style: const TextStyle(fontSize: 12)),
        ),
      );

  void _askWaypointName(
      BuildContext context, AppState app, double lat, double lon) {
    final ctrl = TextEditingController(text: 'WP${app.waypoints.length + 1}');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nowy punkt'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: ctrl,
              decoration: const InputDecoration(labelText: 'Nazwa')),
          const SizedBox(height: 8),
          Text('${lat.toStringAsFixed(6)}, ${lon.toStringAsFixed(6)}',
              style: const TextStyle(fontSize: 12, color: Colors.white54)),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Anuluj')),
          FilledButton(
            onPressed: () {
              app.addWaypoint(lat, lon, ctrl.text);
              Navigator.pop(context);
            },
            child: const Text('Dodaj'),
          ),
        ],
      ),
    );
  }

  void _waypointList(BuildContext context, AppState app) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Consumer<AppState>(
        builder: (context, a, __) => ListView(
          children: [
            const ListTile(
                title: Text('Waypointy',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            for (final w in a.waypoints)
              ListTile(
                leading: const Icon(Icons.place, color: Color(0xFF4EA8FF)),
                title: Text(w.name),
                subtitle: Text(
                    '${w.lat.toStringAsFixed(5)}, ${w.lon.toStringAsFixed(5)}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(
                    icon: const Icon(Icons.navigation, size: 20),
                    onPressed: () {
                      a.gotoWaypoint(w);
                      Navigator.pop(context);
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, size: 20),
                    onPressed: () => a.removeWaypoint(w.id),
                  ),
                ]),
              ),
          ],
        ),
      ),
    );
  }

  void _surveyDialog(BuildContext context, AppState app) {
    final w = TextEditingController(text: '120');
    final h = TextEditingController(text: '120');
    final s = TextEditingController(text: '12');
    final o = TextEditingController(text: '0');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Automatyczne mapowanie dna'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
            'Łódka przepłynie obszar wzorem "kosiarki" wokół aktualnej pozycji, '
            'zbierając pomiary głębokości.',
            style: TextStyle(fontSize: 12, color: Colors.white60),
          ),
          const SizedBox(height: 10),
          TextField(
              controller: w,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Szerokość [m]')),
          TextField(
              controller: h,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Długość [m]')),
          TextField(
              controller: s,
              keyboardType: TextInputType.number,
              decoration:
                  const InputDecoration(labelText: 'Odstęp pasów [m]')),
          TextField(
              controller: o,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Obrót [°]')),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Anuluj')),
          FilledButton(
            onPressed: () {
              app.startSurvey(
                widthM: double.tryParse(w.text) ?? 120,
                heightM: double.tryParse(h.text) ?? 120,
                spacingM: double.tryParse(s.text) ?? 12,
                orientationDeg: double.tryParse(o.text) ?? 0,
              );
              Navigator.pop(context);
            },
            child: const Text('Start'),
          ),
        ],
      ),
    );
  }
}

class _ApBar extends StatelessWidget {
  final AppState app;
  const _ApBar({required this.app});

  @override
  Widget build(BuildContext context) {
    final ap = app.autopilot;
    final st = ap.status;
    final engaged = ap.engaged;
    return Container(
      color: engaged
          ? const Color(0xFF2ED3A7).withValues(alpha: 0.12)
          : const Color(0xFF141F33),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(children: [
        Icon(engaged ? Icons.auto_mode : Icons.pan_tool_alt,
            size: 18,
            color: engaged ? const Color(0xFF2ED3A7) : Colors.white54),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(ap.mode.label,
                  style: const TextStyle(
                      fontSize: 12, fontWeight: FontWeight.bold)),
              Text(
                st.message +
                    (st.distanceToTargetM != null
                        ? '  •  ${st.distanceToTargetM!.toStringAsFixed(0)} m'
                        : '') +
                    (st.etaSeconds != null
                        ? '  •  ETA ${st.etaSeconds!.toStringAsFixed(0)} s'
                        : ''),
                style: const TextStyle(fontSize: 11, color: Colors.white60),
              ),
            ],
          ),
        ),
        if (engaged)
          TextButton(
            onPressed: app.disengageAutopilot,
            child: const Text('Przejmij'),
          ),
      ]),
    );
  }
}

class MapPainter extends CustomPainter {
  final AppState app;
  final MapTransform transform;
  MapPainter({required this.app, required this.transform});

  @override
  void paint(Canvas canvas, Size size) {
    _grid(canvas, size);

    // slad z kolorem wg glebokosci
    if (app.track.length > 1) {
      final depths = app.track.map((t) => t.depthM);
      final dMin = depths.reduce(math.min);
      final dMax = math.max(dMin + 0.5, depths.reduce(math.max));
      for (final p in app.track) {
        final o = transform.toScreen(p.lat, p.lon);
        final v = ((p.depthM - dMin) / (dMax - dMin)).clamp(0.0, 1.0);
        canvas.drawCircle(
          o,
          2.4,
          Paint()
            ..color = Color.lerp(
                const Color(0xFFFFE066), const Color(0xFF12386E), v)!,
        );
      }
    }

    // trasa autopilota
    final route = app.autopilot.route;
    if (route.length > 1) {
      final path = Path();
      for (var i = 0; i < route.length; i++) {
        final o = transform.toScreen(route[i].lat, route[i].lon);
        i == 0 ? path.moveTo(o.dx, o.dy) : path.lineTo(o.dx, o.dy);
      }
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..color = const Color(0xFF2ED3A7).withValues(alpha: 0.7),
      );
    }

    // waypointy
    for (final w in app.waypoints) {
      final o = transform.toScreen(w.lat, w.lon);
      canvas.drawCircle(o, 6, Paint()..color = const Color(0xFF4EA8FF));
      canvas.drawCircle(
          o,
          6,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5
            ..color = Colors.white);
      _text(canvas, w.name, o + const Offset(9, -7), 11, Colors.white70);
    }

    // HOME
    if (app.autopilot.homeLat != null) {
      final o = transform
          .toScreen(app.autopilot.homeLat!, app.autopilot.homeLon!);
      final r = 8.0;
      canvas.drawRect(
        Rect.fromCenter(center: o, width: r * 2, height: r * 2),
        Paint()..color = const Color(0xFFFFD166),
      );
      _text(canvas, 'HOME', o + const Offset(11, -7), 10, Colors.white70);
    }

    // aktualny cel
    final tgt = app.autopilot.target;
    if (tgt != null) {
      final o = transform.toScreen(tgt.lat, tgt.lon);
      final p = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF2ED3A7);
      canvas.drawCircle(o, 14, p);
      canvas.drawLine(o - const Offset(20, 0), o + const Offset(20, 0), p);
      canvas.drawLine(o - const Offset(0, 20), o + const Offset(0, 20), p);
    }

    // lodka
    final g = app.telemetry.gps;
    if (g.valid) {
      final o = transform.toScreen(g.lat, g.lon);
      _boat(canvas, o, app.telemetry.headingDeg);
    }

    _scaleBar(canvas, size);
  }

  void _boat(Canvas canvas, Offset o, double headingDeg) {
    canvas.save();
    canvas.translate(o.dx, o.dy);
    canvas.rotate(deg2rad(headingDeg));
    final path = Path()
      ..moveTo(0, -13)
      ..lineTo(8, 10)
      ..lineTo(0, 5)
      ..lineTo(-8, 10)
      ..close();
    canvas.drawPath(path, Paint()..color = const Color(0xFFFF5C5C));
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = Colors.white,
    );
    canvas.restore();
  }

  void _grid(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.05)
      ..strokeWidth = 1;
    const spacingM = 25.0;
    final px = spacingM * transform.scale;
    if (px < 8) return;
    for (var x = (transform.origin.dx + transform.panX) % px;
        x < size.width;
        x += px) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (var y = (transform.origin.dy + transform.panY) % px;
        y < size.height;
        y += px) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  void _scaleBar(Canvas canvas, Size size) {
    const meters = 50.0;
    final px = meters * transform.scale;
    if (px < 20 || px > size.width * 0.8) return;
    final y = size.height - 18;
    final p = Paint()
      ..color = Colors.white70
      ..strokeWidth = 2;
    canvas.drawLine(Offset(12, y), Offset(12 + px, y), p);
    _text(canvas, '50 m', Offset(12, y - 16), 11, Colors.white70);
  }

  void _text(Canvas c, String s, Offset at, double size, Color color) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(fontSize: size, color: color)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(c, at);
  }

  @override
  bool shouldRepaint(covariant MapPainter old) => true;
}
