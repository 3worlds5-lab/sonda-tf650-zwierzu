import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/models.dart';
import '../state/app_state.dart';

class ControlPage extends StatefulWidget {
  const ControlPage({super.key});

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage> {
  bool _springBack = true; // joystick wraca na srodek po puszczeniu
  double _limit = 1.0; // ograniczenie mocy

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(10),
      child: Column(children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Row(children: [
                const Icon(Icons.sports_esports, size: 18),
                const SizedBox(width: 8),
                const Text('Sterowanie ręczne',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                Text(app.autopilot.mode.label,
                    style: TextStyle(
                      fontSize: 11,
                      color: app.autopilot.engaged
                          ? const Color(0xFF2ED3A7)
                          : Colors.white54,
                    )),
              ]),
              const SizedBox(height: 14),
              Joystick(
                size: math.min(MediaQuery.of(context).size.width - 70, 300),
                springBack: _springBack,
                onChanged: (x, y) {
                  app.setManual(y * _limit, x * _limit);
                },
              ),
              const SizedBox(height: 10),
              _readout(app),
              const SizedBox(height: 6),
              Row(children: [
                const Text('Limit mocy', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    value: _limit,
                    min: 0.2,
                    max: 1.0,
                    divisions: 8,
                    label: '${(_limit * 100).round()}%',
                    onChanged: (v) => setState(() => _limit = v),
                  ),
                ),
                Text('${(_limit * 100).round()}%',
                    style: const TextStyle(fontSize: 12)),
              ]),
              SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: _springBack,
                title: const Text('Powrót drążka na środek',
                    style: TextStyle(fontSize: 13)),
                onChanged: (v) => setState(() => _springBack = v),
              ),
            ]),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Automatyka',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  _chip(Icons.route, 'Start trasy', app.runRoute),
                  _chip(Icons.keyboard_return, 'Powrót HOME', app.returnHome),
                  _chip(Icons.my_location, 'Ustaw HOME', app.setHomeHere),
                  _chip(Icons.add_location_alt, 'Punkt tutaj',
                      () => app.addWaypointHere()),
                  _chip(Icons.pan_tool_alt, 'Tryb ręczny',
                      app.disengageAutopilot),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF4EA8FF)),
                      onPressed: () {
                        HapticFeedback.mediumImpact();
                        app.releaseBait();
                      },
                      icon: const Icon(Icons.download),
                      label: const Text('ZRZUT'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFFFF5C5C)),
                      onPressed: () {
                        HapticFeedback.heavyImpact();
                        app.emergencyStop();
                      },
                      icon: const Icon(Icons.pan_tool),
                      label: const Text('STOP'),
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
        Card(
          child: ExpansionTile(
            title: const Text('Surowe ramki (diagnostyka)',
                style: TextStyle(fontSize: 13)),
            subtitle: Text('Odebrano: ${app.framesReceived}',
                style: const TextStyle(fontSize: 11, color: Colors.white54)),
            children: [
              SizedBox(
                height: 180,
                child: ListView(
                  reverse: true,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: app.rawLog.reversed
                      .take(60)
                      .map((l) => Text(l,
                          style: const TextStyle(
                              fontSize: 10,
                              fontFamily: 'monospace',
                              color: Colors.white54)))
                      .toList(),
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _readout(AppState app) {
    Widget bar(String label, double v, Color c) => Expanded(
          child: Column(children: [
            Text(label,
                style: const TextStyle(fontSize: 10, color: Colors.white54)),
            const SizedBox(height: 4),
            Stack(alignment: Alignment.center, children: [
              Container(height: 8, color: Colors.white10),
              Align(
                alignment: Alignment(v.clamp(-1.0, 1.0), 0),
                child: Container(width: 10, height: 16, color: c),
              ),
            ]),
            Text('${(v * 100).round()}%',
                style: const TextStyle(fontSize: 11)),
          ]),
        );

    return Row(children: [
      bar('GAZ', app.manualThrottle, const Color(0xFF2ED3A7)),
      const SizedBox(width: 14),
      bar('STER', app.manualRudder, const Color(0xFF4EA8FF)),
    ]);
  }

  Widget _chip(IconData i, String label, VoidCallback onTap) =>
      ActionChip(avatar: Icon(i, size: 16), label: Text(label), onPressed: onTap);
}

/// Analogowy drazek. Zwraca x (-1 lewo .. 1 prawo) i y (-1 wstecz .. 1 naprzod).
class Joystick extends StatefulWidget {
  final double size;
  final bool springBack;
  final void Function(double x, double y) onChanged;

  const Joystick({
    super.key,
    required this.size,
    required this.onChanged,
    this.springBack = true,
  });

  @override
  State<Joystick> createState() => _JoystickState();
}

class _JoystickState extends State<Joystick> {
  Offset _knob = Offset.zero; // -1..1

  void _update(Offset local) {
    final r = widget.size / 2;
    var dx = (local.dx - r) / (r - 24);
    var dy = (local.dy - r) / (r - 24);
    final len = math.sqrt(dx * dx + dy * dy);
    if (len > 1) {
      dx /= len;
      dy /= len;
    }
    setState(() => _knob = Offset(dx, dy));
    widget.onChanged(dx, -dy);
  }

  void _release() {
    if (!widget.springBack) return;
    setState(() => _knob = Offset.zero);
    widget.onChanged(0, 0);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (d) => _update(d.localPosition),
      onPanUpdate: (d) => _update(d.localPosition),
      onPanEnd: (_) => _release(),
      onPanCancel: _release,
      child: CustomPaint(
        painter: _JoystickPainter(_knob),
        size: Size.square(widget.size),
      ),
    );
  }
}

class _JoystickPainter extends CustomPainter {
  final Offset knob;
  _JoystickPainter(this.knob);

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width / 2;
    final center = Offset(r, r);

    canvas.drawCircle(center, r - 2, Paint()..color = const Color(0xFF0E1A2E));
    canvas.drawCircle(
        center,
        r - 2,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white12);

    final cross = Paint()
      ..color = Colors.white10
      ..strokeWidth = 1;
    canvas.drawLine(Offset(r, 14), Offset(r, size.height - 14), cross);
    canvas.drawLine(Offset(14, r), Offset(size.width - 14, r), cross);

    final kp = center + Offset(knob.dx * (r - 24), knob.dy * (r - 24));
    canvas.drawCircle(kp, 26, Paint()..color = const Color(0xFF2ED3A7));
    canvas.drawCircle(
        kp,
        26,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant _JoystickPainter old) => old.knob != knob;
}
