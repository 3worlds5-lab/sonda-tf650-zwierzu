import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/models.dart';
import '../state/app_state.dart';
import 'control_page.dart';
import 'map_page.dart';
import 'settings_page.dart';
import 'sonar_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _index = 0;

  static const _pages = [SonarPage(), MapPage(), ControlPage()];
  static const _titles = ['Sonar', 'Mapa i trasa', 'Sterowanie'];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
        actions: [
          _LinkBadge(state: app.link, label: _linkLabel(app)),
          IconButton(
            tooltip: app.connected ? 'Rozłącz' : 'Połącz',
            icon: Icon(app.connected ? Icons.link_off : Icons.link),
            onPressed: () =>
                app.connected ? app.disconnect() : app.connect(),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsPage()),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          const _TelemetryStrip(),
          if (app.lastAlarm != null) _AlarmBar(text: app.lastAlarm!),
          Expanded(child: IndexedStack(index: _index, children: _pages)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFFFF5C5C),
        onPressed: app.emergencyStop,
        child: const Icon(Icons.pan_tool, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniEndTop,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.waves), label: 'Sonar'),
          NavigationDestination(icon: Icon(Icons.map), label: 'Mapa'),
          NavigationDestination(
              icon: Icon(Icons.sports_esports), label: 'Sterowanie'),
        ],
      ),
    );
  }

  String _linkLabel(AppState app) {
    switch (app.linkKind) {
      case LinkKind.simulator:
        return 'SYM';
      case LinkKind.ble:
        return 'BLE';
      case LinkKind.udp:
        return 'UDP';
      case LinkKind.tcp:
        return 'TCP';
    }
  }
}

class _LinkBadge extends StatelessWidget {
  final LinkState state;
  final String label;
  const _LinkBadge({required this.state, required this.label});

  @override
  Widget build(BuildContext context) {
    Color c;
    switch (state) {
      case LinkState.connected:
        c = const Color(0xFF2ED3A7);
        break;
      case LinkState.connecting:
        c = Colors.amber;
        break;
      case LinkState.error:
        c = const Color(0xFFFF5C5C);
        break;
      case LinkState.disconnected:
        c = Colors.grey;
        break;
    }
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        margin: const EdgeInsets.only(right: 4),
        decoration: BoxDecoration(
          color: c.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: c.withValues(alpha: 0.6)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.circle, size: 8, color: c),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  color: c, fontSize: 11, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }
}

class _AlarmBar extends StatelessWidget {
  final String text;
  const _AlarmBar({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Colors.amber.withValues(alpha: 0.18),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(children: [
        const Icon(Icons.warning_amber, size: 16, color: Colors.amber),
        const SizedBox(width: 8),
        Expanded(
            child: Text(text,
                style: const TextStyle(fontSize: 12, color: Colors.amber))),
      ]),
    );
  }
}

class _TelemetryStrip extends StatelessWidget {
  const _TelemetryStrip();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final t = app.telemetry;
    final home = app.distanceHomeM;

    return Container(
      color: const Color(0xFF141F33),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          _cell('GŁĘBOKOŚĆ', '${t.depthM.toStringAsFixed(1)} m',
              big: true, color: const Color(0xFF2ED3A7)),
          _cell('TEMP',
              t.tempC == null ? '--' : '${t.tempC!.toStringAsFixed(1)}°C'),
          _cell('KURS', '${t.headingDeg.toStringAsFixed(0)}°'),
          _cell('PRĘDKOŚĆ',
              '${(t.gps.speedKn * 0.514).toStringAsFixed(1)} m/s'),
          _cell('SAT', '${t.gps.satellites}',
              color: t.gps.valid ? null : const Color(0xFFFF5C5C)),
          _cell('DO HOME',
              home == null ? '--' : '${home.toStringAsFixed(0)} m'),
          _cell('AKU',
              t.boatBatteryV == null
                  ? '--'
                  : '${t.boatBatteryV!.toStringAsFixed(1)}V'),
        ]),
      ),
    );
  }

  Widget _cell(String label, String value,
      {bool big = false, Color? color}) {
    return Container(
      constraints: const BoxConstraints(minWidth: 78),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 9,
                  color: Colors.white54,
                  letterSpacing: 1.1,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(value,
              style: TextStyle(
                  fontSize: big ? 22 : 16,
                  fontWeight: FontWeight.bold,
                  color: color ?? Colors.white)),
        ],
      ),
    );
  }
}
