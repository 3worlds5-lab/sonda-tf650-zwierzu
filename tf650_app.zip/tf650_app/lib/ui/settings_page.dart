import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../state/app_state.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController _host;
  late TextEditingController _port;
  late TextEditingController _ble;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _host = TextEditingController(text: app.host);
    _port = TextEditingController(text: app.port.toString());
    _ble = TextEditingController(text: app.bleNamePrefix);
  }

  @override
  void dispose() {
    _host.dispose();
    _port.dispose();
    _ble.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final c = app.apConfig;

    return Scaffold(
      appBar: AppBar(title: const Text('Ustawienia')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const _Section('Łączność'),
          SegmentedButton<LinkKind>(
            segments: const [
              ButtonSegment(value: LinkKind.simulator, label: Text('Symulator')),
              ButtonSegment(value: LinkKind.ble, label: Text('BLE')),
              ButtonSegment(value: LinkKind.udp, label: Text('UDP')),
              ButtonSegment(value: LinkKind.tcp, label: Text('TCP')),
            ],
            selected: {app.linkKind},
            onSelectionChanged: (s) {
              app.linkKind = s.first;
              app.saveSettings();
            },
          ),
          const SizedBox(height: 10),
          if (app.linkKind == LinkKind.udp || app.linkKind == LinkKind.tcp) ...[
            TextField(
              controller: _host,
              decoration: const InputDecoration(
                  labelText: 'Adres mostu', hintText: '192.168.4.1'),
              onChanged: (v) => app.host = v,
            ),
            TextField(
              controller: _port,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Port'),
              onChanged: (v) => app.port = int.tryParse(v) ?? app.port,
            ),
          ],
          if (app.linkKind == LinkKind.ble)
            TextField(
              controller: _ble,
              decoration: const InputDecoration(
                  labelText: 'Nazwa urządzenia BLE (prefiks)'),
              onChanged: (v) => app.bleNamePrefix = v,
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () async {
              await app.saveSettings();
              await app.connect();
              if (context.mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.link),
            label: const Text('Zapisz i połącz'),
          ),

          const _Section('Autopilot'),
          _slider('Prędkość przelotowa', c.cruiseThrottle, 0.2, 1.0,
              (v) => setState(() => c.cruiseThrottle = v),
              fmt: (v) => '${(v * 100).round()}%'),
          _slider('Promień osiągnięcia punktu', c.arrivalRadiusM, 1, 20,
              (v) => setState(() => c.arrivalRadiusM = v),
              fmt: (v) => '${v.toStringAsFixed(0)} m'),
          _slider('Wzmocnienie kursu (Kp)', c.kp, 0.005, 0.08,
              (v) => setState(() => c.kp = v),
              fmt: (v) => v.toStringAsFixed(3)),
          _slider('Tłumienie (Kd)', c.kd, 0.0, 0.05,
              (v) => setState(() => c.kd = v),
              fmt: (v) => v.toStringAsFixed(3)),
          _slider('Alarm płycizny', c.shallowAlarmM, 0.2, 3.0,
              (v) => setState(() => c.shallowAlarmM = v),
              fmt: (v) => '${v.toStringAsFixed(1)} m'),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: app.saveSettings,
            icon: const Icon(Icons.save_outlined),
            label: const Text('Zapisz ustawienia autopilota'),
          ),

          const _Section('Diagnostyka'),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Eksport surowych ramek'),
            subtitle: const Text(
                'Wyślij log, żeby dostroić parser do Twojego zestawu',
                style: TextStyle(fontSize: 12)),
            trailing: const Icon(Icons.ios_share),
            onTap: () async {
              final f = await app.exportRawLog();
              await Share.shareXFiles([XFile(f.path)],
                  text: 'Log ramek TF650');
            },
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Odebrane ramki: ${app.framesReceived}'),
            subtitle: Text(
              app.lastFrameAt == null
                  ? 'Brak danych'
                  : 'Ostatnia: ${app.lastFrameAt!.toLocal().toString().substring(11, 19)}',
              style: const TextStyle(fontSize: 12),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _slider(String label, double value, double min, double max,
      ValueChanged<double> onChanged,
      {required String Function(double) fmt}) {
    return Row(children: [
      SizedBox(
          width: 140,
          child: Text(label, style: const TextStyle(fontSize: 12))),
      Expanded(
        child: Slider(
          value: value.clamp(min, max),
          min: min,
          max: max,
          onChanged: onChanged,
        ),
      ),
      SizedBox(
          width: 52,
          child: Text(fmt(value),
              style: const TextStyle(fontSize: 12),
              textAlign: TextAlign.right)),
    ]);
  }
}

class _Section extends StatelessWidget {
  final String title;
  const _Section(this.title);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 6),
        child: Text(title.toUpperCase(),
            style: const TextStyle(
                fontSize: 11,
                letterSpacing: 1.4,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2ED3A7))),
      );
}
