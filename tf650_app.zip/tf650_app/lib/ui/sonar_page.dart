import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/models.dart';
import '../state/app_state.dart';

class SonarPage extends StatefulWidget {
  const SonarPage({super.key});

  @override
  State<SonarPage> createState() => _SonarPageState();
}

class _SonarPageState extends State<SonarPage> {
  double _range = 0; // 0 = auto
  int _palette = 0;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cols = app.echogram.toList();

    var maxDepth = _range;
    if (maxDepth <= 0) {
      final m = cols.isEmpty
          ? 10.0
          : cols.map((c) => c.depthM).reduce(math.max);
      maxDepth = (m * 1.25).clamp(3.0, 60.0);
    }

    return Column(
      children: [
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: const Color(0xFF05070D),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white10),
            ),
            clipBehavior: Clip.antiAlias,
            child: cols.isEmpty
                ? const Center(
                    child: Text('Brak danych sonaru.\nPołącz się lub włącz symulator.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white38)))
                : CustomPaint(
                    painter: EchogramPainter(
                      columns: cols,
                      maxDepth: maxDepth,
                      palette: _palette,
                    ),
                    child: const SizedBox.expand(),
                  ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          child: Row(children: [
            const Text('Zakres:', style: TextStyle(fontSize: 12)),
            const SizedBox(width: 8),
            DropdownButton<double>(
              value: _range,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 0.0, child: Text('AUTO')),
                DropdownMenuItem(value: 5.0, child: Text('5 m')),
                DropdownMenuItem(value: 10.0, child: Text('10 m')),
                DropdownMenuItem(value: 20.0, child: Text('20 m')),
                DropdownMenuItem(value: 40.0, child: Text('40 m')),
              ],
              onChanged: (v) => setState(() => _range = v ?? 0),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Paleta',
              icon: const Icon(Icons.palette_outlined),
              onPressed: () => setState(() => _palette = (_palette + 1) % 3),
            ),
            IconButton(
              tooltip: 'Wyczyść',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: app.clearTrack,
            ),
          ]),
        ),
      ],
    );
  }
}

class EchogramPainter extends CustomPainter {
  final List<SonarColumn> columns;
  final double maxDepth;
  final int palette;

  EchogramPainter({
    required this.columns,
    required this.maxDepth,
    this.palette = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final colW = size.width / AppState.maxColumns;
    final startX = size.width - columns.length * colW;

    // tlo
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF05070D));

    for (var i = 0; i < columns.length; i++) {
      final c = columns[i];
      final x = startX + i * colW;
      final echo = c.echo;
      if (echo != null && echo.isNotEmpty) {
        final binH = size.height / echo.length;
        for (var b = 0; b < echo.length; b++) {
          final v = echo[b] / 255.0;
          if (v < 0.06) continue;
          canvas.drawRect(
            Rect.fromLTWH(x, b * binH, colW + 0.6, binH + 0.6),
            Paint()..color = _color(v),
          );
        }
      } else {
        // brak surowego echa - rysujemy syntetyczne dno z glebokosci
        final y = (c.depthM / maxDepth).clamp(0.0, 1.0) * size.height;
        canvas.drawRect(
          Rect.fromLTWH(x, y, colW + 0.6, size.height - y),
          Paint()..color = _color(0.9),
        );
      }
    }

    // siatka glebokosci
    final grid = Paint()
      ..color = Colors.white24
      ..strokeWidth = 0.7;
    final steps = 5;
    for (var i = 1; i < steps; i++) {
      final y = size.height * i / steps;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      _label(canvas, '${(maxDepth * i / steps).toStringAsFixed(1)} m',
          Offset(6, y - 14));
    }

    // aktualna glebokosc - duza cyfra
    if (columns.isNotEmpty) {
      final last = columns.last;
      _label(
        canvas,
        '${last.depthM.toStringAsFixed(1)} m',
        Offset(size.width - 110, 10),
        size: 26,
        color: const Color(0xFF2ED3A7),
        bold: true,
      );
      if (last.tempC != null) {
        _label(canvas, '${last.tempC!.toStringAsFixed(1)} °C',
            Offset(size.width - 110, 44),
            size: 13, color: Colors.white70);
      }
      if (last.bottomHardness != null) {
        _label(
            canvas,
            'twardość dna: ${(last.bottomHardness! * 100).round()}%',
            Offset(size.width - 170, 62),
            size: 11,
            color: Colors.white54);
      }
    }
  }

  Color _color(double v) {
    switch (palette) {
      case 1: // bursztyn
        return Color.lerp(const Color(0xFF3A2200), const Color(0xFFFFD27F), v)!;
      case 2: // szarosci
        return Color.lerp(const Color(0xFF101010), Colors.white, v)!;
      default: // niebiesko-zolta
        if (v < 0.5) {
          return Color.lerp(
              const Color(0xFF07214A), const Color(0xFF1E8FD5), v * 2)!;
        }
        return Color.lerp(
            const Color(0xFF1E8FD5), const Color(0xFFFFE066), (v - 0.5) * 2)!;
    }
  }

  void _label(Canvas canvas, String text, Offset at,
      {double size = 11, Color color = Colors.white60, bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: size,
          fontWeight: bold ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, at);
  }

  @override
  bool shouldRepaint(covariant EchogramPainter old) =>
      old.columns.length != columns.length ||
      old.maxDepth != maxDepth ||
      old.palette != palette ||
      (columns.isNotEmpty &&
          old.columns.isNotEmpty &&
          old.columns.last.time != columns.last.time);
}
