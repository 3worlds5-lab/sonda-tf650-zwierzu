import 'dart:math' as math;

/// Pozycja GPS z odbiornika TF650.
class GpsFix {
  final double lat;
  final double lon;
  final double speedKn;
  final double courseDeg;
  final int satellites;
  final bool valid;
  final DateTime time;

  const GpsFix({
    required this.lat,
    required this.lon,
    this.speedKn = 0,
    this.courseDeg = 0,
    this.satellites = 0,
    this.valid = false,
    required this.time,
  });

  static GpsFix invalid() =>
      GpsFix(lat: 0, lon: 0, valid: false, time: DateTime.now());

  GpsFix copyWith({
    double? lat,
    double? lon,
    double? speedKn,
    double? courseDeg,
    int? satellites,
    bool? valid,
    DateTime? time,
  }) =>
      GpsFix(
        lat: lat ?? this.lat,
        lon: lon ?? this.lon,
        speedKn: speedKn ?? this.speedKn,
        courseDeg: courseDeg ?? this.courseDeg,
        satellites: satellites ?? this.satellites,
        valid: valid ?? this.valid,
        time: time ?? this.time,
      );
}

/// Jedna kolumna echogramu.
///
/// [echo] to opcjonalna surowa obwiednia sonaru (0..255, indeks 0 = powierzchnia).
/// Jesli most nie dostarcza surowych danych, kolumna jest syntetyzowana z glebokosci.
class SonarColumn {
  final double depthM;
  final double? tempC;
  final double? bottomHardness; // 0..1
  final List<int>? echo;
  final DateTime time;

  const SonarColumn({
    required this.depthM,
    this.tempC,
    this.bottomHardness,
    this.echo,
    required this.time,
  });
}

/// Pelny stan telemetrii lodki.
class Telemetry {
  final GpsFix gps;
  final double depthM;
  final double? tempC;
  final double headingDeg; // z kompasu TF650
  final double? boatBatteryV;
  final double? displayBatteryV;
  final DateTime updated;

  const Telemetry({
    required this.gps,
    this.depthM = 0,
    this.tempC,
    this.headingDeg = 0,
    this.boatBatteryV,
    this.displayBatteryV,
    required this.updated,
  });

  factory Telemetry.empty() =>
      Telemetry(gps: GpsFix.invalid(), updated: DateTime.now());

  Telemetry copyWith({
    GpsFix? gps,
    double? depthM,
    double? tempC,
    double? headingDeg,
    double? boatBatteryV,
    double? displayBatteryV,
    DateTime? updated,
  }) =>
      Telemetry(
        gps: gps ?? this.gps,
        depthM: depthM ?? this.depthM,
        tempC: tempC ?? this.tempC,
        headingDeg: headingDeg ?? this.headingDeg,
        boatBatteryV: boatBatteryV ?? this.boatBatteryV,
        displayBatteryV: displayBatteryV ?? this.displayBatteryV,
        updated: updated ?? DateTime.now(),
      );
}

class Waypoint {
  final String id;
  String name;
  final double lat;
  final double lon;

  Waypoint({
    required this.id,
    required this.name,
    required this.lat,
    required this.lon,
  });

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'lat': lat, 'lon': lon};

  factory Waypoint.fromJson(Map<String, dynamic> j) => Waypoint(
        id: j['id'] as String,
        name: j['name'] as String,
        lat: (j['lat'] as num).toDouble(),
        lon: (j['lon'] as num).toDouble(),
      );
}

/// Punkt sladu z pomiarem glebokosci (baza pod eksport do ReefMaster).
class TrackPoint {
  final double lat;
  final double lon;
  final double depthM;
  final double? tempC;
  final DateTime time;

  const TrackPoint({
    required this.lat,
    required this.lon,
    required this.depthM,
    this.tempC,
    required this.time,
  });
}

/// Komenda sterowania wysylana do lodki.
class ControlCommand {
  /// -1.0 (wstecz) .. 1.0 (pelny naprzod)
  final double throttle;

  /// -1.0 (lewo) .. 1.0 (prawo)
  final double rudder;

  /// Wyrzutnia / zrzut zanety (impuls).
  final bool release;

  const ControlCommand({
    this.throttle = 0,
    this.rudder = 0,
    this.release = false,
  });

  double get clampedThrottle => throttle.clamp(-1.0, 1.0).toDouble();
  double get clampedRudder => rudder.clamp(-1.0, 1.0).toDouble();

  /// Format ramki: $CTRL,<throttle_pct>,<rudder_pct>,<release>*<CS>
  String toNmea() {
    final t = (clampedThrottle * 100).round();
    final r = (clampedRudder * 100).round();
    final body = 'CTRL,$t,$r,${release ? 1 : 0}';
    return '\$$body*${_checksum(body)}';
  }

  static String _checksum(String body) {
    var cs = 0;
    for (final c in body.codeUnits) {
      cs ^= c;
    }
    return cs.toRadixString(16).toUpperCase().padLeft(2, '0');
  }
}

enum AutopilotMode {
  off, // sterowanie wylacznie reczne
  hold, // silniki stop, trzymaj pozycje logicznie (brak napedu)
  goto, // plyn do wybranego waypointa
  route, // plyn trasa po kolejnych waypointach
  home, // powrot do punktu HOME
  survey, // automatyczne mapowanie dna (wzor "kosiarka")
}

extension AutopilotModeLabel on AutopilotMode {
  String get label {
    switch (this) {
      case AutopilotMode.off:
        return 'RĘCZNY';
      case AutopilotMode.hold:
        return 'STOP';
      case AutopilotMode.goto:
        return 'DO PUNKTU';
      case AutopilotMode.route:
        return 'TRASA';
      case AutopilotMode.home:
        return 'POWRÓT';
      case AutopilotMode.survey:
        return 'MAPOWANIE';
    }
  }
}

enum LinkState { disconnected, connecting, connected, error }

/// Prosty filtr wygladzajacy (EMA) uzywany przy glebokosci i kursie.
class Ema {
  final double alpha;
  double? _value;
  Ema(this.alpha);

  double add(double x) {
    final v = _value;
    _value = v == null ? x : alpha * x + (1 - alpha) * v;
    return _value!;
  }

  double? get value => _value;
  void reset() => _value = null;
}

/// Normalizacja kata do zakresu -180..180.
double wrap180(double deg) {
  var d = deg % 360.0;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  return d;
}

double deg2rad(double d) => d * math.pi / 180.0;
double rad2deg(double r) => r * 180.0 / math.pi;
