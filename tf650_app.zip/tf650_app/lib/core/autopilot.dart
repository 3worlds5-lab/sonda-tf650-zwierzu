import 'dart:math' as math;

import 'geo.dart';
import 'models.dart';

class AutopilotConfig {
  /// Promien, w ktorym waypoint uznajemy za osiagniety [m].
  double arrivalRadiusM;

  /// Predkosc przelotowa 0..1.
  double cruiseThrottle;

  /// Predkosc przy dolotowaniu 0..1.
  double approachThrottle;

  /// Wzmocnienia regulatora kursu.
  double kp;
  double kd;

  /// Wplyw odchylenia od linii kursu (cross-track) na zadany kurs [deg/m].
  double xteGain;

  /// Alarm plycizny - ponizej tej glebokosci autopilot hamuje [m].
  double shallowAlarmM;

  /// Failsafe: brak nowej telemetrii dluzej niz X -> STOP.
  Duration telemetryTimeout;

  AutopilotConfig({
    this.arrivalRadiusM = 4.0,
    this.cruiseThrottle = 0.75,
    this.approachThrottle = 0.35,
    this.kp = 0.030,
    this.kd = 0.012,
    this.xteGain = 1.2,
    this.shallowAlarmM = 0.6,
    this.telemetryTimeout = const Duration(seconds: 5),
  });
}

class NavStatus {
  final double? distanceToTargetM;
  final double? bearingToTargetDeg;
  final double? crossTrackM;
  final double? etaSeconds;
  final String message;

  const NavStatus({
    this.distanceToTargetM,
    this.bearingToTargetDeg,
    this.crossTrackM,
    this.etaSeconds,
    this.message = '',
  });
}

/// Logika autopilota. Czysta funkcja stanu -> komenda, bez UI i bez I/O.
class Autopilot {
  final AutopilotConfig config;

  AutopilotMode mode = AutopilotMode.off;
  Waypoint? target;
  List<Waypoint> route = [];
  int routeIndex = 0;
  double? homeLat;
  double? homeLon;

  /// Punkt, z ktorego rozpoczeto ostatni odcinek (do liczenia cross-track).
  double? _legFromLat;
  double? _legFromLon;

  double _lastHeadingError = 0;
  DateTime _lastTick = DateTime.now();
  NavStatus status = const NavStatus(message: 'Autopilot wyłączony');

  Autopilot(this.config);

  void setHome(double lat, double lon) {
    homeLat = lat;
    homeLon = lon;
  }

  void startGoto(Waypoint wp, Telemetry t) {
    target = wp;
    route = [];
    routeIndex = 0;
    mode = AutopilotMode.goto;
    _beginLeg(t);
  }

  void startRoute(List<Waypoint> wps, Telemetry t) {
    if (wps.isEmpty) return;
    route = List.of(wps);
    routeIndex = 0;
    target = route.first;
    mode = AutopilotMode.route;
    _beginLeg(t);
  }

  void startHome(Telemetry t) {
    if (homeLat == null || homeLon == null) return;
    target = Waypoint(
        id: '__home__', name: 'HOME', lat: homeLat!, lon: homeLon!);
    mode = AutopilotMode.home;
    _beginLeg(t);
  }

  void startSurvey(List<Waypoint> pattern, Telemetry t) {
    if (pattern.isEmpty) return;
    route = List.of(pattern);
    routeIndex = 0;
    target = route.first;
    mode = AutopilotMode.survey;
    _beginLeg(t);
  }

  void stop() {
    mode = AutopilotMode.hold;
    target = null;
    route = [];
    routeIndex = 0;
    status = const NavStatus(message: 'STOP');
  }

  void disengage() {
    mode = AutopilotMode.off;
    target = null;
    status = const NavStatus(message: 'Sterowanie ręczne');
  }

  void _beginLeg(Telemetry t) {
    _legFromLat = t.gps.valid ? t.gps.lat : target?.lat;
    _legFromLon = t.gps.valid ? t.gps.lon : target?.lon;
    _lastHeadingError = 0;
  }

  bool get engaged =>
      mode != AutopilotMode.off && mode != AutopilotMode.hold;

  /// Glowny krok regulatora. Wywolywany cyklicznie (np. 5 Hz).
  ControlCommand tick(Telemetry t) {
    final now = DateTime.now();
    final dt = math.max(0.02, now.difference(_lastTick).inMilliseconds / 1000.0);
    _lastTick = now;

    if (mode == AutopilotMode.off) {
      return const ControlCommand();
    }
    if (mode == AutopilotMode.hold) {
      status = const NavStatus(message: 'STOP - silniki wyłączone');
      return const ControlCommand();
    }

    // Failsafe 1: utrata telemetrii.
    if (now.difference(t.updated) > config.telemetryTimeout) {
      status = const NavStatus(message: 'FAILSAFE: brak telemetrii - STOP');
      mode = AutopilotMode.hold;
      return const ControlCommand();
    }

    // Failsafe 2: brak fixa GPS.
    if (!t.gps.valid) {
      status = const NavStatus(message: 'Brak fixa GPS - autopilot wstrzymany');
      return const ControlCommand();
    }

    final tgt = target;
    if (tgt == null) {
      status = const NavStatus(message: 'Brak celu');
      mode = AutopilotMode.hold;
      return const ControlCommand();
    }

    final dist = distanceM(t.gps.lat, t.gps.lon, tgt.lat, tgt.lon);
    final brg = bearingDeg(t.gps.lat, t.gps.lon, tgt.lat, tgt.lon);

    // Osiagnieto waypoint?
    if (dist <= config.arrivalRadiusM) {
      final advanced = _advance(t);
      if (!advanced) {
        status = NavStatus(
          distanceToTargetM: dist,
          bearingToTargetDeg: brg,
          message: mode == AutopilotMode.home
              ? 'Łódka wróciła do HOME'
              : 'Cel osiągnięty',
        );
        mode = AutopilotMode.hold;
        target = null;
        return const ControlCommand();
      }
      return tick(t); // przelicz od razu dla nowego celu
    }

    // Cross-track wzgledem linii start->cel.
    double xte = 0;
    if (_legFromLat != null && _legFromLon != null) {
      xte = crossTrackM(_legFromLat!, _legFromLon!, tgt.lat, tgt.lon,
          t.gps.lat, t.gps.lon);
    }

    // Kurs zadany = namiar na cel skorygowany o odchylenie od linii.
    final correction = (-xte * config.xteGain).clamp(-35.0, 35.0);
    final desired = (brg + correction + 360) % 360;

    // Zrodlo kursu: kompas TF650, a przy ruchu takze COG z GPS.
    final actual = (t.gps.speedKn > 0.4 && t.gps.courseDeg > 0)
        ? t.gps.courseDeg
        : t.headingDeg;

    final err = wrap180(desired - actual);
    final dErr = (err - _lastHeadingError) / dt;
    _lastHeadingError = err;

    final double rudder =
        (config.kp * err + config.kd * dErr).clamp(-1.0, 1.0).toDouble();

    // Gaz: zwalniamy przy dolocie i przy duzym bledzie kursu.
    double throttle = dist < config.arrivalRadiusM * 4
        ? config.approachThrottle
        : config.cruiseThrottle;
    throttle = throttle *
        (1.0 - 0.6 * (err.abs() / 180.0) * 3).clamp(0.25, 1.0).toDouble();

    // Failsafe 3: plycizna.
    var msg = 'Płynie do: ${tgt.name}';
    if (t.depthM > 0 && t.depthM < config.shallowAlarmM) {
      throttle = math.min(throttle, 0.2);
      msg = 'UWAGA: płycizna ${t.depthM.toStringAsFixed(1)} m - zwolniono';
    }

    final sog = t.gps.speedKn * 0.514444;
    status = NavStatus(
      distanceToTargetM: dist,
      bearingToTargetDeg: brg,
      crossTrackM: xte,
      etaSeconds: sog > 0.2 ? dist / sog : null,
      message: msg,
    );

    return ControlCommand(throttle: throttle, rudder: rudder);
  }

  /// Przejscie do kolejnego punktu. Zwraca false, jesli trasa sie skonczyla.
  bool _advance(Telemetry t) {
    if (mode == AutopilotMode.route || mode == AutopilotMode.survey) {
      if (routeIndex < route.length - 1) {
        routeIndex++;
        target = route[routeIndex];
        _beginLeg(t);
        return true;
      }
    }
    return false;
  }
}

/// Generator wzoru "kosiarka" do automatycznego mapowania dna.
/// Obszar zadany srodkiem, szerokoscia, wysokoscia i orientacja.
List<Waypoint> generateSurveyPattern({
  required double centerLat,
  required double centerLon,
  required double widthM,
  required double heightM,
  required double laneSpacingM,
  double orientationDeg = 0,
}) {
  final proj = LocalProjection(centerLat, centerLon);
  final lanes = math.max(2, (widthM / laneSpacingM).ceil() + 1);
  final out = <Waypoint>[];
  final rad = deg2rad(orientationDeg);
  var idx = 0;

  for (var i = 0; i < lanes; i++) {
    final lx = -widthM / 2 + i * (widthM / (lanes - 1));
    final ys = (i % 2 == 0)
        ? [-heightM / 2, heightM / 2]
        : [heightM / 2, -heightM / 2];
    for (final ly in ys) {
      // obrot o orientacje
      final rx = lx * math.cos(rad) - ly * math.sin(rad);
      final ry = lx * math.sin(rad) + ly * math.cos(rad);
      final ll = proj.toLatLon(rx, ry);
      out.add(Waypoint(
        id: 'survey_${idx++}',
        name: 'S$idx',
        lat: ll[0],
        lon: ll[1],
      ));
    }
  }
  return out;
}
