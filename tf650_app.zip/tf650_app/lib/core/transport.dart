import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import 'geo.dart';
import 'models.dart';

/// Wspolny interfejs laczosci. Aplikacja nie wie, czym gada z lodka.
abstract class Transport {
  String get name;

  /// Strumien linii tekstowych (ramek) przychodzacych z mostu.
  Stream<String> get lines;

  /// Strumien stanu polaczenia.
  Stream<LinkState> get state;

  LinkState get currentState;

  Future<void> connect();
  Future<void> disconnect();
  Future<void> send(String line);
}

abstract class BaseTransport implements Transport {
  final StreamController<String> _lines = StreamController<String>.broadcast();
  final StreamController<LinkState> _state =
      StreamController<LinkState>.broadcast();
  LinkState _current = LinkState.disconnected;

  @override
  Stream<String> get lines => _lines.stream;

  @override
  Stream<LinkState> get state => _state.stream;

  @override
  LinkState get currentState => _current;

  void emitLine(String l) {
    if (!_lines.isClosed) _lines.add(l);
  }

  void setState(LinkState s) {
    _current = s;
    if (!_state.isClosed) _state.add(s);
  }

  Future<void> dispose() async {
    await _lines.close();
    await _state.close();
  }
}

/// Bufor sklejajacy pakiety w pelne linie zakonczone \n lub \r.
class LineBuffer {
  final StringBuffer _buf = StringBuffer();
  final void Function(String) onLine;
  LineBuffer(this.onLine);

  void add(String chunk) {
    for (final ch in chunk.split('')) {
      if (ch == '\n' || ch == '\r') {
        final s = _buf.toString();
        _buf.clear();
        if (s.trim().isNotEmpty) onLine(s.trim());
      } else {
        _buf.write(ch);
        if (_buf.length > 4096) _buf.clear(); // ochrona przed smieciami
      }
    }
  }
}

// ---------------------------------------------------------------------------
// UDP (ESP32 w trybie Wi-Fi AP lub w sieci lokalnej)
// ---------------------------------------------------------------------------
class UdpTransport extends BaseTransport {
  final String remoteHost;
  final int remotePort;
  final int listenPort;

  RawDatagramSocket? _sock;
  late final LineBuffer _lb;

  UdpTransport({
    this.remoteHost = '192.168.4.1',
    this.remotePort = 4210,
    this.listenPort = 4211,
  }) {
    _lb = LineBuffer(emitLine);
  }

  @override
  String get name => 'Wi-Fi / UDP $remoteHost:$remotePort';

  @override
  Future<void> connect() async {
    setState(LinkState.connecting);
    try {
      _sock = await RawDatagramSocket.bind(InternetAddress.anyIPv4, listenPort);
      _sock!.broadcastEnabled = true;
      _sock!.listen((event) {
        if (event == RawSocketEvent.read) {
          final dg = _sock!.receive();
          if (dg != null) _lb.add(utf8.decode(dg.data, allowMalformed: true));
        }
      });
      // "handshake" - most odpowiada ramkami telemetrii
      await send('\$PTSLH,HELLO');
      setState(LinkState.connected);
    } catch (_) {
      setState(LinkState.error);
      rethrow;
    }
  }

  @override
  Future<void> disconnect() async {
    _sock?.close();
    _sock = null;
    setState(LinkState.disconnected);
  }

  @override
  Future<void> send(String line) async {
    final s = _sock;
    if (s == null) return;
    s.send(utf8.encode('$line\r\n'), InternetAddress(remoteHost), remotePort);
  }
}

// ---------------------------------------------------------------------------
// TCP
// ---------------------------------------------------------------------------
class TcpTransport extends BaseTransport {
  final String host;
  final int port;
  Socket? _socket;
  late final LineBuffer _lb;

  TcpTransport({this.host = '192.168.4.1', this.port = 4210}) {
    _lb = LineBuffer(emitLine);
  }

  @override
  String get name => 'TCP $host:$port';

  @override
  Future<void> connect() async {
    setState(LinkState.connecting);
    try {
      _socket = await Socket.connect(host, port,
          timeout: const Duration(seconds: 6));
      _socket!.listen(
        (data) => _lb.add(utf8.decode(data, allowMalformed: true)),
        onDone: () => setState(LinkState.disconnected),
        onError: (_) => setState(LinkState.error),
        cancelOnError: true,
      );
      setState(LinkState.connected);
    } catch (_) {
      setState(LinkState.error);
      rethrow;
    }
  }

  @override
  Future<void> disconnect() async {
    await _socket?.close();
    _socket = null;
    setState(LinkState.disconnected);
  }

  @override
  Future<void> send(String line) async {
    _socket?.write('$line\r\n');
  }
}

// ---------------------------------------------------------------------------
// BLE - Nordic UART Service (ESP32 / HM-10 w trybie NUS)
// ---------------------------------------------------------------------------
class BleTransport extends BaseTransport {
  static final Guid nusService =
      Guid('6e400001-b5a3-f393-e0a9-e50e24dcca9e');
  static final Guid nusRx = Guid('6e400002-b5a3-f393-e0a9-e50e24dcca9e'); // write
  static final Guid nusTx = Guid('6e400003-b5a3-f393-e0a9-e50e24dcca9e'); // notify

  final String deviceNamePrefix;
  BluetoothDevice? _device;
  BluetoothCharacteristic? _rx;
  StreamSubscription? _notifySub;
  StreamSubscription? _scanSub;
  late final LineBuffer _lb;

  BleTransport({this.deviceNamePrefix = 'TF650'}) {
    _lb = LineBuffer(emitLine);
  }

  @override
  String get name => 'BLE ($deviceNamePrefix)';

  @override
  Future<void> connect() async {
    setState(LinkState.connecting);
    try {
      if (await FlutterBluePlus.isSupported == false) {
        setState(LinkState.error);
        return;
      }
      final completer = Completer<BluetoothDevice?>();
      _scanSub = FlutterBluePlus.scanResults.listen((results) {
        for (final r in results) {
          final n = r.device.platformName;
          if (n.toUpperCase().startsWith(deviceNamePrefix.toUpperCase())) {
            if (!completer.isCompleted) completer.complete(r.device);
          }
        }
      });
      await FlutterBluePlus.startScan(
        withServices: [nusService],
        timeout: const Duration(seconds: 10),
      );
      final dev = await completer.future
          .timeout(const Duration(seconds: 12), onTimeout: () => null);
      await FlutterBluePlus.stopScan();
      await _scanSub?.cancel();

      if (dev == null) {
        setState(LinkState.error);
        return;
      }
      _device = dev;
      await dev.connect(timeout: const Duration(seconds: 10));
      final services = await dev.discoverServices();
      for (final s in services) {
        if (s.uuid != nusService) continue;
        for (final c in s.characteristics) {
          if (c.uuid == nusTx) {
            await c.setNotifyValue(true);
            _notifySub = c.lastValueStream.listen(
              (v) => _lb.add(utf8.decode(v, allowMalformed: true)),
            );
          } else if (c.uuid == nusRx) {
            _rx = c;
          }
        }
      }
      setState(_rx != null ? LinkState.connected : LinkState.error);
    } catch (_) {
      setState(LinkState.error);
      rethrow;
    }
  }

  @override
  Future<void> disconnect() async {
    await _notifySub?.cancel();
    await _scanSub?.cancel();
    await _device?.disconnect();
    _device = null;
    _rx = null;
    setState(LinkState.disconnected);
  }

  @override
  Future<void> send(String line) async {
    final c = _rx;
    if (c == null) return;
    await c.write(utf8.encode('$line\r\n'), withoutResponse: true);
  }
}

// ---------------------------------------------------------------------------
// SYMULATOR - pelny model lodki + sonaru, dziala bez sprzetu
// ---------------------------------------------------------------------------
class SimulatorTransport extends BaseTransport {
  final double startLat;
  final double startLon;
  final int hz;

  Timer? _timer;
  final math.Random _rnd = math.Random(42);

  double _lat = 0, _lon = 0;
  double _heading = 45; // stopnie
  double _speed = 0; // m/s
  double _throttle = 0, _rudder = 0;
  double _t = 0;

  SimulatorTransport({
    this.startLat = 50.0380,
    this.startLon = 15.7790, // okolice Pardubic - dowolny akwen testowy
    this.hz = 5,
  }) {
    _lat = startLat;
    _lon = startLon;
  }

  @override
  String get name => 'SYMULATOR (bez sprzętu)';

  @override
  Future<void> connect() async {
    setState(LinkState.connecting);
    _timer?.cancel();
    _timer = Timer.periodic(
        Duration(milliseconds: (1000 / hz).round()), (_) => _tick());
    setState(LinkState.connected);
  }

  @override
  Future<void> disconnect() async {
    _timer?.cancel();
    _timer = null;
    setState(LinkState.disconnected);
  }

  @override
  Future<void> send(String line) async {
    if (!line.startsWith(r'$CTRL')) return;
    final body = line.substring(1).split('*').first;
    final f = body.split(',');
    if (f.length < 3) return;
    _throttle = ((double.tryParse(f[1]) ?? 0) / 100).clamp(-1.0, 1.0);
    _rudder = ((double.tryParse(f[2]) ?? 0) / 100).clamp(-1.0, 1.0);
  }

  void _tick() {
    final dt = 1.0 / hz;
    _t += dt;

    // Model: max ~1.6 m/s, bezwladnosc, ster dziala proporcjonalnie do predkosci.
    final targetSpeed = _throttle * 1.6;
    _speed += (targetSpeed - _speed) * math.min(1.0, dt * 1.2);
    _heading += _rudder * 55 * dt * (0.35 + _speed / 1.6);
    _heading = (_heading % 360 + 360) % 360;

    final dist = _speed * dt;
    final p = destinationPoint(_lat, _lon, _heading, dist);
    _lat = p[0];
    _lon = p[1];

    // Syntetyczne dno: misa z garbem i rowem + lekki szum.
    final proj = LocalProjection(startLat, startLon);
    final xy = proj.toXY(_lat, _lon);
    final x = xy[0], y = xy[1];
    final r = math.sqrt(x * x + y * y);
    var depth = 1.2 + r / 42.0;
    depth += 1.8 * math.sin(x / 55.0) * math.cos(y / 70.0);
    depth -= 2.2 * math.exp(-((x - 90) * (x - 90) + (y - 40) * (y - 40)) / 2600);
    depth += 0.04 * (_rnd.nextDouble() - 0.5);
    depth = depth.clamp(0.4, 18.0);

    final temp = 17.5 + 1.5 * math.sin(_t / 90.0);
    final hardness = (0.35 + 0.3 * math.sin(x / 120.0)).clamp(0.0, 1.0);

    emitLine(_nmea('GPRMC,${_utc()},A,${_lat2nmea(_lat)},${_lon2nmea(_lon)},'
        '${(_speed * 1.94384).toStringAsFixed(2)},${_heading.toStringAsFixed(1)},'
        '${_date()},,,A'));
    emitLine(_nmea('GPGGA,${_utc()},${_lat2nmea(_lat)},${_lon2nmea(_lon)},1,'
        '${8 + _rnd.nextInt(4)},0.9,120.0,M,45.0,M,,'));
    emitLine(_nmea('HCHDG,${_heading.toStringAsFixed(1)},,,,'));
    emitLine(_nmea('SDMTW,${temp.toStringAsFixed(1)},C'));
    emitLine(_nmea('PTSLE,${depth.toStringAsFixed(2)},'
        '${(hardness * 100).round()},${_echo(depth)}'));
    emitLine(_nmea('PTSLB,${(12.4 - _t / 3600).toStringAsFixed(2)},3.92'));
  }

  /// Syntetyczna obwiednia echa: powierzchnia, ewentualne ryby, dno, ogon.
  String _echo(double depth) {
    const bins = 96;
    const maxDepth = 20.0;
    final vals = List<int>.filled(bins, 0);
    final bottomBin = (depth / maxDepth * bins).round().clamp(0, bins - 1);
    for (var i = 0; i < bins; i++) {
      var v = 6 + _rnd.nextInt(10);
      if (i < 2) v = 120; // echo powierzchniowe
      if ((i - bottomBin).abs() <= 1) v = 245;
      if (i > bottomBin && i - bottomBin < 8) {
        v = (200 * math.exp(-(i - bottomBin) / 3.0)).round();
      }
      vals[i] = v.clamp(0, 255);
    }
    // ryby
    if (_rnd.nextDouble() < 0.12) {
      final fb = (bottomBin * (0.25 + _rnd.nextDouble() * 0.6)).round();
      for (var i = fb; i < math.min(fb + 3, bins); i++) {
        vals[i] = 200;
      }
    }
    return vals.join(';');
  }

  String _nmea(String body) {
    var cs = 0;
    for (final c in body.codeUnits) {
      cs ^= c;
    }
    return '\$$body*${cs.toRadixString(16).toUpperCase().padLeft(2, '0')}';
  }

  String _utc() {
    final n = DateTime.now().toUtc();
    return '${_p(n.hour)}${_p(n.minute)}${_p(n.second)}.00';
  }

  String _date() {
    final n = DateTime.now().toUtc();
    return '${_p(n.day)}${_p(n.month)}${_p(n.year % 100)}';
  }

  String _p(int v) => v.toString().padLeft(2, '0');

  String _lat2nmea(double lat) {
    final a = lat.abs();
    final d = a.floor();
    final m = (a - d) * 60;
    return '${_p(d)}${m.toStringAsFixed(4).padLeft(7, '0')},${lat >= 0 ? 'N' : 'S'}';
  }

  String _lon2nmea(double lon) {
    final a = lon.abs();
    final d = a.floor();
    final m = (a - d) * 60;
    return '${d.toString().padLeft(3, '0')}'
        '${m.toStringAsFixed(4).padLeft(7, '0')},${lon >= 0 ? 'E' : 'W'}';
  }
}
