import 'dart:math' as math;

import 'models.dart';

const double earthRadiusM = 6371000.0;

/// Odleglosc w metrach (haversine).
double distanceM(double lat1, double lon1, double lat2, double lon2) {
  final dLat = deg2rad(lat2 - lat1);
  final dLon = deg2rad(lon2 - lon1);
  final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(deg2rad(lat1)) *
          math.cos(deg2rad(lat2)) *
          math.sin(dLon / 2) *
          math.sin(dLon / 2);
  return 2 * earthRadiusM * math.atan2(math.sqrt(a), math.sqrt(1 - a));
}

/// Namiar (kurs) z punktu 1 do 2, w stopniach 0..360.
double bearingDeg(double lat1, double lon1, double lat2, double lon2) {
  final p1 = deg2rad(lat1);
  final p2 = deg2rad(lat2);
  final dl = deg2rad(lon2 - lon1);
  final y = math.sin(dl) * math.cos(p2);
  final x = math.cos(p1) * math.sin(p2) -
      math.sin(p1) * math.cos(p2) * math.cos(dl);
  return (rad2deg(math.atan2(y, x)) + 360) % 360;
}

/// Punkt oddalony o [distM] metrow w kierunku [bearing].
List<double> destinationPoint(
    double lat, double lon, double bearing, double distM) {
  final d = distM / earthRadiusM;
  final b = deg2rad(bearing);
  final p1 = deg2rad(lat);
  final l1 = deg2rad(lon);
  final p2 = math.asin(
      math.sin(p1) * math.cos(d) + math.cos(p1) * math.sin(d) * math.cos(b));
  final l2 = l1 +
      math.atan2(math.sin(b) * math.sin(d) * math.cos(p1),
          math.cos(d) - math.sin(p1) * math.sin(p2));
  return [rad2deg(p2), (rad2deg(l2) + 540) % 360 - 180];
}

/// Lokalne wspolrzedne metryczne (x = wschod, y = polnoc) wzgledem punktu odniesienia.
/// Wystarczajaco dokladne dla akwenu o rozmiarze kilku kilometrow.
class LocalProjection {
  final double refLat;
  final double refLon;
  late final double _mPerDegLat;
  late final double _mPerDegLon;

  LocalProjection(this.refLat, this.refLon) {
    _mPerDegLat = 111132.92 -
        559.82 * math.cos(2 * deg2rad(refLat)) +
        1.175 * math.cos(4 * deg2rad(refLat));
    _mPerDegLon = 111412.84 * math.cos(deg2rad(refLat)) -
        93.5 * math.cos(3 * deg2rad(refLat));
  }

  /// [x, y] w metrach.
  List<double> toXY(double lat, double lon) =>
      [(lon - refLon) * _mPerDegLon, (lat - refLat) * _mPerDegLat];

  /// [lat, lon] z metrow.
  List<double> toLatLon(double x, double y) =>
      [refLat + y / _mPerDegLat, refLon + x / _mPerDegLon];
}

/// Odchylenie od linii kursu (cross-track error) w metrach.
/// Dodatnie = lodka na prawo od linii A->B.
double crossTrackM(double latA, double lonA, double latB, double lonB,
    double latP, double lonP) {
  final d13 = distanceM(latA, lonA, latP, lonP) / earthRadiusM;
  final t13 = deg2rad(bearingDeg(latA, lonA, latP, lonP));
  final t12 = deg2rad(bearingDeg(latA, lonA, latB, lonB));
  return math.asin(math.sin(d13) * math.sin(t13 - t12)) * earthRadiusM;
}
