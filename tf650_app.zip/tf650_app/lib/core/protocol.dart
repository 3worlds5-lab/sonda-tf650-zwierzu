import 'models.dart';

/// ============================================================
///  WARSTWA PROTOKOLU - JEDYNE MIEJSCE DO PODMIANY
/// ============================================================
///
/// Toslon nie publikuje specyfikacji swojego lacza 2.4 GHz. Most (ESP32)
/// czyta strumien z wyjscia danych TF650 i przekazuje go dalej linia po linii.
/// W praktyce wyjscie "to PC" jest zgodne z NMEA 0183, wiec domyslny parser
/// obsluguje standardowe zdania. Jesli u Ciebie ramki wygladaja inaczej,
/// wystarczy napisac wlasna klase implementujaca [TelemetryParser]
/// i podac ja w [AppState] - reszta aplikacji sie nie zmienia.
abstract class TelemetryParser {
  /// Zwraca zaktualizowana telemetrie albo null, jesli linia nic nie wnosi.
  Telemetry? feed(String line, Telemetry current);

  /// Zwraca kolumne echogramu, jesli linia ja zawierala.
  SonarColumn? lastColumn();
}

/// Parser NMEA 0183 + rozszerzenia \$PTSL (ramki wlasne mostu).
class Nmea0183Parser implements TelemetryParser {
  SonarColumn? _column;

  @override
  SonarColumn? lastColumn() {
    final c = _column;
    _column = null;
    return c;
  }

  @override
  Telemetry? feed(String rawLine, Telemetry current) {
    final line = rawLine.trim();
    if (line.isEmpty || !line.startsWith(r'$')) return null;
    if (!_checksumOk(line)) return null;

    final body = line.substring(1).split('*').first;
    final f = body.split(',');
    if (f.isEmpty) return null;

    final sentence = f[0].toUpperCase();
    // Talker ID (pierwsze 2 znaki) ignorujemy - liczy sie typ zdania.
    final type = sentence.length >= 5 ? sentence.substring(2) : sentence;

    switch (type) {
      case 'RMC':
        return _parseRmc(f, current);
      case 'GGA':
        return _parseGga(f, current);
      case 'VTG':
        return _parseVtg(f, current);
      case 'HDG':
      case 'HDM':
      case 'HDT':
        return _parseHeading(f, current);
      case 'DBT':
        return _parseDbt(f, current);
      case 'DPT':
        return _parseDpt(f, current);
      case 'MTW':
        return _parseMtw(f, current);
      default:
        if (sentence == 'PTSLE') return _parseEcho(f, current);
        if (sentence == 'PTSLB') return _parseBattery(f, current);
        return null;
    }
  }

  // --- standardowe zdania -------------------------------------------------

  Telemetry? _parseRmc(List<String> f, Telemetry c) {
    if (f.length < 8) return null;
    final valid = f[2].toUpperCase() == 'A';
    final lat = _coord(f[3], f[4]);
    final lon = _coord(f[5], f[6]);
    if (lat == null || lon == null) {
      return c.copyWith(gps: c.gps.copyWith(valid: false));
    }
    final sog = double.tryParse(f[7]) ?? c.gps.speedKn;
    final cog = f.length > 8 ? (double.tryParse(f[8]) ?? c.gps.courseDeg) : c.gps.courseDeg;
    return c.copyWith(
      gps: c.gps.copyWith(
        lat: lat,
        lon: lon,
        speedKn: sog,
        courseDeg: cog,
        valid: valid,
        time: DateTime.now(),
      ),
      updated: DateTime.now(),
    );
  }

  Telemetry? _parseGga(List<String> f, Telemetry c) {
    if (f.length < 8) return null;
    final lat = _coord(f[2], f[3]);
    final lon = _coord(f[4], f[5]);
    final quality = int.tryParse(f[6]) ?? 0;
    final sats = int.tryParse(f[7]) ?? c.gps.satellites;
    if (lat == null || lon == null) {
      return c.copyWith(gps: c.gps.copyWith(satellites: sats, valid: false));
    }
    return c.copyWith(
      gps: c.gps.copyWith(
        lat: lat,
        lon: lon,
        satellites: sats,
        valid: quality > 0,
        time: DateTime.now(),
      ),
      updated: DateTime.now(),
    );
  }

  Telemetry? _parseVtg(List<String> f, Telemetry c) {
    if (f.length < 6) return null;
    final cog = double.tryParse(f[1]);
    final sog = double.tryParse(f[5]);
    return c.copyWith(
      gps: c.gps.copyWith(
        courseDeg: cog ?? c.gps.courseDeg,
        speedKn: sog ?? c.gps.speedKn,
      ),
      updated: DateTime.now(),
    );
  }

  Telemetry? _parseHeading(List<String> f, Telemetry c) {
    if (f.length < 2) return null;
    final h = double.tryParse(f[1]);
    if (h == null) return null;
    return c.copyWith(headingDeg: (h % 360 + 360) % 360, updated: DateTime.now());
  }

  /// \$SDDBT,<ft>,f,<m>,M,<F>,F
  Telemetry? _parseDbt(List<String> f, Telemetry c) {
    if (f.length < 4) return null;
    final m = double.tryParse(f[3]);
    if (m == null) return null;
    _column = SonarColumn(depthM: m, tempC: c.tempC, time: DateTime.now());
    return c.copyWith(depthM: m, updated: DateTime.now());
  }

  /// \$SDDPT,<m>,<offset>
  Telemetry? _parseDpt(List<String> f, Telemetry c) {
    if (f.length < 2) return null;
    final m = double.tryParse(f[1]);
    if (m == null) return null;
    final offset = f.length > 2 ? (double.tryParse(f[2]) ?? 0) : 0;
    final depth = m + offset;
    _column = SonarColumn(depthM: depth, tempC: c.tempC, time: DateTime.now());
    return c.copyWith(depthM: depth, updated: DateTime.now());
  }

  Telemetry? _parseMtw(List<String> f, Telemetry c) {
    if (f.length < 2) return null;
    final t = double.tryParse(f[1]);
    if (t == null) return null;
    return c.copyWith(tempC: t, updated: DateTime.now());
  }

  // --- ramki wlasne mostu -------------------------------------------------

  /// \$PTSLE,<depth_m>,<hardness_0_100>,<b64 lub lista 0..255 rozdzielona ';'>
  Telemetry? _parseEcho(List<String> f, Telemetry c) {
    if (f.length < 2) return null;
    final depth = double.tryParse(f[1]) ?? c.depthM;
    final hard = f.length > 2 ? (double.tryParse(f[2]) ?? 0) / 100.0 : null;
    List<int>? echo;
    if (f.length > 3 && f[3].isNotEmpty) {
      echo = f[3]
          .split(';')
          .map((s) => int.tryParse(s) ?? 0)
          .map((v) => v.clamp(0, 255))
          .cast<int>()
          .toList();
    }
    _column = SonarColumn(
      depthM: depth,
      tempC: c.tempC,
      bottomHardness: hard,
      echo: echo,
      time: DateTime.now(),
    );
    return c.copyWith(depthM: depth, updated: DateTime.now());
  }

  /// \$PTSLB,<boat_v>,<display_v>
  Telemetry? _parseBattery(List<String> f, Telemetry c) {
    if (f.length < 2) return null;
    return c.copyWith(
      boatBatteryV: double.tryParse(f[1]),
      displayBatteryV: f.length > 2 ? double.tryParse(f[2]) : null,
      updated: DateTime.now(),
    );
  }

  // --- pomocnicze ---------------------------------------------------------

  /// NMEA: ddmm.mmmm / dddmm.mmmm + N/S/E/W
  static double? _coord(String value, String hemi) {
    if (value.isEmpty) return null;
    final dot = value.indexOf('.');
    if (dot < 3) return null;
    final degLen = dot - 2;
    final deg = double.tryParse(value.substring(0, degLen));
    final min = double.tryParse(value.substring(degLen));
    if (deg == null || min == null) return null;
    var v = deg + min / 60.0;
    final h = hemi.toUpperCase();
    if (h == 'S' || h == 'W') v = -v;
    return v;
  }

  static bool _checksumOk(String line) {
    final star = line.lastIndexOf('*');
    if (star < 0) return true; // brak sumy - akceptujemy (niektore mosty jej nie dodaja)
    final body = line.substring(1, star);
    final given = line.substring(star + 1).trim();
    var cs = 0;
    for (final ch in body.codeUnits) {
      cs ^= ch;
    }
    return cs.toRadixString(16).toUpperCase().padLeft(2, '0') ==
        given.toUpperCase();
  }
}
