import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/autopilot.dart';
import '../core/geo.dart';
import '../core/models.dart';
import '../core/protocol.dart';
import '../core/transport.dart';

enum LinkKind { simulator, ble, udp, tcp }

class AppState extends ChangeNotifier {
  // --- konfiguracja laczosci ---
  LinkKind linkKind = LinkKind.simulator;
  String host = '192.168.4.1';
  int port = 4210;
  String bleNamePrefix = 'TF650';

  // --- warstwy ---
  Transport? _transport;
  TelemetryParser parser = Nmea0183Parser();
  final AutopilotConfig apConfig = AutopilotConfig();
  late final Autopilot autopilot = Autopilot(apConfig);

  StreamSubscription? _lineSub;
  StreamSubscription? _stateSub;
  Timer? _controlTimer;

  // --- dane ---
  LinkState link = LinkState.disconnected;
  Telemetry telemetry = Telemetry.empty();
  final ListQueue<SonarColumn> echogram = ListQueue<SonarColumn>();
  final List<TrackPoint> track = [];
  final List<Waypoint> waypoints = [];
  final List<String> rawLog = [];

  static const int maxColumns = 600;
  static const int maxTrack = 20000;
  static const int maxRawLog = 300;

  // --- sterowanie reczne ---
  double manualThrottle = 0;
  double manualRudder = 0;
  bool manualEnabled = true;

  // --- alarmy ---
  double fishAlarmDepthMin = 0.5;
  bool shallowAlarmTriggered = false;
  String? lastAlarm;

  // --- statystyki ---
  int framesReceived = 0;
  DateTime? lastFrameAt;

  bool get connected => link == LinkState.connected;
  double get depthM => telemetry.depthM;

  // ------------------------------------------------------------------
  // Cykl zycia polaczenia
  // ------------------------------------------------------------------
  Future<void> connect() async {
    await disconnect();
    switch (linkKind) {
      case LinkKind.simulator:
        _transport = SimulatorTransport();
        break;
      case LinkKind.ble:
        _transport = BleTransport(deviceNamePrefix: bleNamePrefix);
        break;
      case LinkKind.udp:
        _transport = UdpTransport(remoteHost: host, remotePort: port);
        break;
      case LinkKind.tcp:
        _transport = TcpTransport(host: host, port: port);
        break;
    }

    _lineSub = _transport!.lines.listen(_onLine);
    _stateSub = _transport!.state.listen((s) {
      link = s;
      notifyListeners();
    });

    try {
      await _transport!.connect();
    } catch (e) {
      lastAlarm = 'Błąd połączenia: $e';
      link = LinkState.error;
    }

    _controlTimer?.cancel();
    _controlTimer =
        Timer.periodic(const Duration(milliseconds: 200), (_) => _controlTick());
    notifyListeners();
  }

  Future<void> disconnect() async {
    _controlTimer?.cancel();
    _controlTimer = null;
    await _lineSub?.cancel();
    await _stateSub?.cancel();
    _lineSub = null;
    _stateSub = null;
    await _transport?.disconnect();
    _transport = null;
    link = LinkState.disconnected;
    autopilot.disengage();
    notifyListeners();
  }

  void _onLine(String line) {
    framesReceived++;
    lastFrameAt = DateTime.now();

    rawLog.add(line);
    if (rawLog.length > maxRawLog) rawLog.removeAt(0);

    final updated = parser.feed(line, telemetry);
    if (updated != null) telemetry = updated;

    final col = parser.lastColumn();
    if (col != null) {
      echogram.addLast(col);
      while (echogram.length > maxColumns) {
        echogram.removeFirst();
      }
      if (telemetry.gps.valid && col.depthM > 0) {
        track.add(TrackPoint(
          lat: telemetry.gps.lat,
          lon: telemetry.gps.lon,
          depthM: col.depthM,
          tempC: col.tempC,
          time: col.time,
        ));
        if (track.length > maxTrack) track.removeAt(0);
        autopilot.homeLat ??= telemetry.gps.lat;
        autopilot.homeLon ??= telemetry.gps.lon;
      }
      // alarm plycizny
      final shallow = col.depthM > 0 && col.depthM < apConfig.shallowAlarmM;
      if (shallow && !shallowAlarmTriggered) {
        shallowAlarmTriggered = true;
        lastAlarm = 'ALARM: płycizna ${col.depthM.toStringAsFixed(1)} m';
      } else if (!shallow) {
        shallowAlarmTriggered = false;
      }
    }
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // Petla sterowania (5 Hz)
  // ------------------------------------------------------------------
  void _controlTick() {
    final t = _transport;
    if (t == null || link != LinkState.connected) return;

    ControlCommand cmd;
    if (autopilot.mode == AutopilotMode.off) {
      if (!manualEnabled) return;
      cmd = ControlCommand(throttle: manualThrottle, rudder: manualRudder);
    } else {
      cmd = autopilot.tick(telemetry);
      if (autopilot.mode == AutopilotMode.hold) {
        manualThrottle = 0;
        manualRudder = 0;
      }
    }
    t.send(cmd.toNmea());
  }

  // ------------------------------------------------------------------
  // Sterowanie reczne
  // ------------------------------------------------------------------
  void setManual(double throttle, double rudder) {
    manualThrottle = throttle.clamp(-1.0, 1.0);
    manualRudder = rudder.clamp(-1.0, 1.0);
    if (autopilot.engaged) autopilot.disengage(); // reczne ma priorytet
    notifyListeners();
  }

  void emergencyStop() {
    manualThrottle = 0;
    manualRudder = 0;
    autopilot.stop();
    _transport?.send(const ControlCommand().toNmea());
    lastAlarm = 'STOP awaryjny';
    notifyListeners();
  }

  void releaseBait() {
    _transport?.send(const ControlCommand(release: true).toNmea());
    lastAlarm = 'Zrzut zanęty';
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // Autopilot
  // ------------------------------------------------------------------
  void gotoWaypoint(Waypoint wp) {
    autopilot.startGoto(wp, telemetry);
    notifyListeners();
  }

  void runRoute() {
    if (waypoints.isEmpty) return;
    autopilot.startRoute(waypoints, telemetry);
    notifyListeners();
  }

  void returnHome() {
    autopilot.startHome(telemetry);
    notifyListeners();
  }

  void setHomeHere() {
    if (!telemetry.gps.valid) return;
    autopilot.setHome(telemetry.gps.lat, telemetry.gps.lon);
    lastAlarm = 'Ustawiono HOME';
    notifyListeners();
  }

  void startSurvey({
    required double widthM,
    required double heightM,
    required double spacingM,
    double orientationDeg = 0,
  }) {
    if (!telemetry.gps.valid) {
      lastAlarm = 'Brak GPS - nie można rozpocząć mapowania';
      notifyListeners();
      return;
    }
    final pattern = generateSurveyPattern(
      centerLat: telemetry.gps.lat,
      centerLon: telemetry.gps.lon,
      widthM: widthM,
      heightM: heightM,
      laneSpacingM: spacingM,
      orientationDeg: orientationDeg,
    );
    autopilot.startSurvey(pattern, telemetry);
    notifyListeners();
  }

  void disengageAutopilot() {
    autopilot.disengage();
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // Waypointy
  // ------------------------------------------------------------------
  void addWaypointHere([String? name]) {
    if (!telemetry.gps.valid) return;
    addWaypoint(telemetry.gps.lat, telemetry.gps.lon, name);
  }

  void addWaypoint(double lat, double lon, [String? name]) {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    waypoints.add(Waypoint(
      id: id,
      name: name ?? 'WP${waypoints.length + 1}',
      lat: lat,
      lon: lon,
    ));
    _saveWaypoints();
    notifyListeners();
  }

  void removeWaypoint(String id) {
    waypoints.removeWhere((w) => w.id == id);
    _saveWaypoints();
    notifyListeners();
  }

  void clearTrack() {
    track.clear();
    echogram.clear();
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // Eksport (CSV zgodny z importem do ReefMaster)
  // ------------------------------------------------------------------
  Future<File> exportCsv() async {
    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final file = File('${dir.path}/tf650_$ts.csv');
    final sb = StringBuffer('latitude,longitude,depth_m,temp_c,timestamp\n');
    for (final p in track) {
      sb.writeln('${p.lat.toStringAsFixed(7)},${p.lon.toStringAsFixed(7)},'
          '${p.depthM.toStringAsFixed(2)},'
          '${p.tempC?.toStringAsFixed(1) ?? ''},'
          '${p.time.toIso8601String()}');
    }
    await file.writeAsString(sb.toString());
    return file;
  }

  /// Eksport surowych ramek - przydatny przy dostrajaniu parsera do Twojego sprzetu.
  Future<File> exportRawLog() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(
        '${dir.path}/tf650_raw_${DateTime.now().millisecondsSinceEpoch}.txt');
    await file.writeAsString(rawLog.join('\n'));
    return file;
  }

  // ------------------------------------------------------------------
  // Ustawienia
  // ------------------------------------------------------------------
  Future<void> loadSettings() async {
    final p = await SharedPreferences.getInstance();
    linkKind = LinkKind.values[p.getInt('linkKind') ?? 0];
    host = p.getString('host') ?? host;
    port = p.getInt('port') ?? port;
    bleNamePrefix = p.getString('blePrefix') ?? bleNamePrefix;
    apConfig.cruiseThrottle = p.getDouble('cruise') ?? apConfig.cruiseThrottle;
    apConfig.arrivalRadiusM =
        p.getDouble('arrival') ?? apConfig.arrivalRadiusM;
    apConfig.kp = p.getDouble('kp') ?? apConfig.kp;
    apConfig.kd = p.getDouble('kd') ?? apConfig.kd;
    apConfig.shallowAlarmM =
        p.getDouble('shallow') ?? apConfig.shallowAlarmM;

    final raw = p.getStringList('waypoints') ?? [];
    waypoints
      ..clear()
      ..addAll(raw.map((s) => Waypoint.fromJson(jsonDecode(s))));
    notifyListeners();
  }

  Future<void> saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('linkKind', linkKind.index);
    await p.setString('host', host);
    await p.setInt('port', port);
    await p.setString('blePrefix', bleNamePrefix);
    await p.setDouble('cruise', apConfig.cruiseThrottle);
    await p.setDouble('arrival', apConfig.arrivalRadiusM);
    await p.setDouble('kp', apConfig.kp);
    await p.setDouble('kd', apConfig.kd);
    await p.setDouble('shallow', apConfig.shallowAlarmM);
    notifyListeners();
  }

  Future<void> _saveWaypoints() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
        'waypoints', waypoints.map((w) => jsonEncode(w.toJson())).toList());
  }

  // ------------------------------------------------------------------
  double? get distanceHomeM {
    if (!telemetry.gps.valid ||
        autopilot.homeLat == null ||
        autopilot.homeLon == null) {
      return null;
    }
    return distanceM(telemetry.gps.lat, telemetry.gps.lon, autopilot.homeLat!,
        autopilot.homeLon!);
  }

  @override
  void dispose() {
    disconnect();
    super.dispose();
  }
}
