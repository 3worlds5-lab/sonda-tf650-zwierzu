# TF650 Control — aplikacja na Android i iOS

Aplikacja mobilna do sonaru **Toslon TF650** (echosonda + GPS + kompas) ze sterowaniem łódką:
ręcznym (joystick) i automatycznym (autopilot po waypointach, powrót HOME, automatyczne mapowanie dna).

Jedna baza kodu we **Flutterze** → Android i iOS.

---

## 1. Uruchomienie w 3 minuty (bez sprzętu)

```bash
# wymagany Flutter 3.29 lub nowszy (Dart 3.7+)
flutter --version

# utwórz szkielet projektu z platformami
flutter create --platforms=android,ios tf650_app
cd tf650_app

# wgraj pliki z tej paczki (nadpisując)
#   lib/        -> tf650_app/lib/
#   pubspec.yaml-> tf650_app/pubspec.yaml

flutter pub get
flutter run
```

Po starcie aplikacja jest w trybie **SYMULATOR** — od razu widzisz działający echogram,
pływającą łódkę na mapie, autopilota i joystick. Nic nie musisz podłączać.
Wciśnij ikonę 🔗 w pasku górnym, żeby wystartować symulację.

---

## 2. Co aplikacja potrafi

**Sonar**
- echogram w czasie rzeczywistym (przewijany), 3 palety kolorów
- zakres AUTO / 5 / 10 / 20 / 40 m
- głębokość, temperatura wody, twardość dna
- alarm płycizny

**Mapa i nawigacja**
- ślad łódki kolorowany według głębokości (podgląd batymetrii na żywo)
- waypointy: dodaj przytrzymaniem palca na mapie lub „Punkt tu"
- HOME, dystans do HOME, trasa z wielu punktów
- eksport pomiarów do **CSV** (lat, lon, głębokość, temperatura, czas) — do zaimportowania w ReefMaster

**Sterowanie**
- analogowy joystick (gaz + ster), limit mocy, opcja powrotu drążka na środek
- przycisk **ZRZUT** i wielki czerwony **STOP** dostępny z każdego ekranu
- autopilot: DO PUNKTU / TRASA / POWRÓT / MAPOWANIE (wzór „kosiarka")
- regulator kursu PD + korekta odchylenia od linii kursu (cross-track)
- failsafe: utrata telemetrii, brak fixa GPS i płycizna automatycznie zatrzymują/zwalniają łódkę
- ręczny ruch drążkiem **natychmiast** rozłącza autopilota

---

## 3. Podłączenie do prawdziwego TF650 — przeczytaj koniecznie

TF650 nadaje z łódki na swój wyświetlacz **własnym, zamkniętym łączem 2,4 GHz**.
Telefon nie ma takiego odbiornika i Toslon nie publikuje specyfikacji ramek.
Dlatego aplikacja **nie łączy się z sondą bezpośrednio** — potrzebny jest most:

```
[sonda w łódce] --2.4GHz--> [wyświetlacz TF650] --kabel danych--> [ESP32] --BLE/Wi-Fi--> [telefon]
```

Firmware mostu jest w `firmware/esp32_bridge/esp32_bridge.ino` (Arduino / ESP32).
Most:
- czyta strumień z portu „to PC" wyświetlacza,
- rozgłasza ramki po BLE (Nordic UART) i UDP,
- przyjmuje komendy `$CTRL` z telefonu i zamienia je na sygnał PWM dla sterownika łódki.

**Uwagi sprzętowe**
- wyjście danych bywa 5 V TTL albo RS-232 → przy RS-232 użyj konwertera MAX3232, przy 5 V dzielnika napięcia; podanie 5 V na pin ESP32 go zniszczy,
- masa musi być wspólna,
- prędkość portu: zacznij od 4800 bps (standard NMEA 0183), sprawdź też 9600 i 38400.

### Dostrojenie protokołu do Twojego zestawu
1. Podłącz most, w aplikacji wybierz BLE lub UDP i połącz się.
2. Wejdź w **Ustawienia → Eksport surowych ramek** i wyślij sobie plik.
3. Jeśli widzisz zdania typu `$SDDBT`, `$GPRMC`, `$SDMTW` — działa bez zmian.
4. Jeśli format jest inny, podmieniasz **jeden plik**: `lib/core/protocol.dart`
   (klasa implementująca `TelemetryParser`). Reszta aplikacji zostaje bez zmian.

### Sterowanie łódką
TF650 to **tylko echosonda — nie steruje napędem**. Sterowanie ręczne i autopilot działają przez
most ESP32 wpięty w miejsce wyjść odbiornika RC (PWM na GPIO18/19) albo przez sterownik
przyjmujący komendy tekstowe. Jeśli masz autopilota Toslon XPilot, jego łącze jest osobne i
również wymaga mostu.

---

## 4. Uprawnienia

**Android** — `android/app/src/main/AndroidManifest.xml`, wewnątrz `<manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
<uses-permission android:name="android.permission.BLUETOOTH_SCAN"
    android:usesPermissionFlags="neverForLocation"/>
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
```
`minSdkVersion` ustaw na 21 lub wyżej (`android/app/build.gradle`).

**iOS** — `ios/Runner/Info.plist`:

```xml
<key>NSBluetoothAlwaysUsageDescription</key>
<string>Połączenie z mostem sonaru TF650</string>
<key>NSLocalNetworkUsageDescription</key>
<string>Komunikacja z mostem w sieci lokalnej</string>
<key>NSBonjourServices</key>
<array><string>_tf650._udp</string></array>
```

---

## 5. Struktura kodu

```
lib/
  core/
    models.dart      # modele danych, komendy, tryby
    geo.dart         # odległości, namiary, projekcja lokalna, cross-track
    protocol.dart    # PARSER — jedyne miejsce do podmiany pod Twój sprzęt
    transport.dart   # BLE / UDP / TCP / SYMULATOR (wspólny interfejs)
    autopilot.dart   # regulator kursu, tryby, failsafe, generator mapowania
  state/
    app_state.dart   # stan aplikacji, pętla sterowania 5 Hz, eksport CSV
  ui/
    home_page.dart   # nawigacja + pasek telemetrii + STOP
    sonar_page.dart  # echogram (CustomPainter)
    map_page.dart    # mapa, ślad, waypointy, autopilot
    control_page.dart# joystick, automatyka, podgląd ramek
    settings_page.dart
firmware/esp32_bridge/esp32_bridge.ino
```

Brak zależności od map online — mapa jest rysowana lokalnie, więc działa nad wodą bez zasięgu.

---

## 6. Bezpieczeństwo

Autopilot steruje realną łódką. Zanim puścisz go na wodzie:
- przetestuj najpierw w symulatorze, potem przy brzegu z małym limitem mocy,
- sprawdź, czy STOP faktycznie zatrzymuje napęd,
- sprawdź failsafe mostu (wyłącz Bluetooth w telefonie — łódka powinna stanąć w ~1,5 s),
- zawsze miej pod ręką oryginalny nadajnik RC.
