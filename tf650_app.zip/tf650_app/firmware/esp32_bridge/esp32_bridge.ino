/*
 * TF650 BRIDGE - ESP32
 * --------------------------------------------------------------
 * Most pomiedzy wyjsciem danych sonaru Toslon TF650 (port "to PC")
 * a telefonem z aplikacja TF650 Control.
 *
 * Kanaly:
 *   1) BLE  - Nordic UART Service, nazwa "TF650-BRIDGE"
 *   2) Wi-Fi - punkt dostepowy "TF650-BRIDGE" (192.168.4.1),
 *              UDP: odbior 4210, rozglaszanie telemetrii na 4211
 *
 * Polaczenie sprzetowe:
 *   TF650 TX  -> ESP32 GPIO16 (RX2)   [UWAGA: przez dzielnik 5V->3.3V,
 *                                      jesli wyjscie jest 5 V / RS232 -> uzyj MAX3232]
 *   GND       -> GND (wspolna masa!)
 *   ESP32 TX2 (GPIO17) -> wejscie sterownika lodki / odbiornika RC (opcjonalnie)
 *
 * Ramki sterujace przychodzace z telefonu:
 *   $CTRL,<gaz -100..100>,<ster -100..100>,<zrzut 0|1>*CS
 * Domyslnie sa przekazywane dalej na Serial2 oraz zamieniane na sygnal PWM
 * (kanaly serwa) na GPIO18 / GPIO19 - do wpiecia zamiast wyjsc odbiornika RC.
 *
 * Biblioteki: ESP32 Arduino core (wbudowane BLE), brak zewnetrznych zaleznosci.
 */

#include <WiFi.h>
#include <WiFiUdp.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// ----------------------- KONFIGURACJA -----------------------
#define SONAR_RX_PIN     16
#define SONAR_TX_PIN     17
#define SONAR_BAUD       4800      // typowe dla NMEA 0183; sprawdz swoj zestaw (9600/38400)

#define PWM_THROTTLE_PIN 18
#define PWM_RUDDER_PIN   19
#define FAILSAFE_MS      1500      // brak komend z telefonu -> silniki stop

const char* AP_SSID = "TF650-BRIDGE";
const char* AP_PASS = "tf650bridge";
const uint16_t UDP_IN_PORT  = 4210;
const uint16_t UDP_OUT_PORT = 4211;

#define NUS_SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define NUS_RX_UUID      "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define NUS_TX_UUID      "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

// ----------------------- STAN -----------------------
WiFiUDP udp;
BLECharacteristic* txChar = nullptr;
bool bleConnected = false;
unsigned long lastCmdMs = 0;
int throttlePct = 0;
int rudderPct = 0;

String sonarLine;

// ----------------------- BLE CALLBACKS -----------------------
class ServerCB : public BLEServerCallbacks {
  void onConnect(BLEServer* s) override { bleConnected = true; }
  void onDisconnect(BLEServer* s) override {
    bleConnected = false;
    throttlePct = 0; rudderPct = 0;
    BLEDevice::startAdvertising();
  }
};

void handleCommand(const String& line);

class RxCB : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    String v = String(c->getValue().c_str());
    int start = 0;
    while (true) {
      int nl = v.indexOf('\n', start);
      String part = (nl < 0) ? v.substring(start) : v.substring(start, nl);
      part.trim();
      if (part.length()) handleCommand(part);
      if (nl < 0) break;
      start = nl + 1;
    }
  }
};

// ----------------------- POMOCNICZE -----------------------
bool checksumOk(const String& line) {
  int star = line.lastIndexOf('*');
  if (star < 0) return true;
  uint8_t cs = 0;
  for (int i = 1; i < star; i++) cs ^= line[i];
  char buf[3];
  snprintf(buf, sizeof(buf), "%02X", cs);
  return line.substring(star + 1) == String(buf);
}

void broadcast(const String& line) {
  // BLE
  if (bleConnected && txChar) {
    String out = line + "\r\n";
    // NUS ma limit MTU - tniemy na porcje po 180 B
    for (int i = 0; i < out.length(); i += 180) {
      String chunk = out.substring(i, min((int)out.length(), i + 180));
      txChar->setValue((uint8_t*)chunk.c_str(), chunk.length());
      txChar->notify();
      delay(3);
    }
  }
  // UDP broadcast
  udp.beginPacket(IPAddress(255, 255, 255, 255), UDP_OUT_PORT);
  udp.print(line);
  udp.print("\r\n");
  udp.endPacket();
}

void applyOutputs() {
  // 1000-2000 us, neutral 1500
  int thUs = 1500 + throttlePct * 5;
  int ruUs = 1500 + rudderPct * 5;
  ledcWrite(0, map(thUs, 0, 20000, 0, 65535));
  ledcWrite(1, map(ruUs, 0, 20000, 0, 65535));

  // przekazanie dalej tekstowo (jesli sterownik lodki tego oczekuje)
  Serial2.printf("$CTRL,%d,%d\r\n", throttlePct, rudderPct);
}

void handleCommand(const String& line) {
  if (!line.startsWith("$CTRL")) return;
  int c1 = line.indexOf(',');
  int c2 = line.indexOf(',', c1 + 1);
  int c3 = line.indexOf(',', c2 + 1);
  if (c1 < 0 || c2 < 0) return;
  throttlePct = constrain(line.substring(c1 + 1, c2).toInt(), -100, 100);
  String rs = (c3 < 0) ? line.substring(c2 + 1) : line.substring(c2 + 1, c3);
  rudderPct = constrain(rs.toInt(), -100, 100);
  lastCmdMs = millis();
  applyOutputs();
}

// ----------------------- SETUP -----------------------
void setup() {
  Serial.begin(115200);
  Serial2.begin(SONAR_BAUD, SERIAL_8N1, SONAR_RX_PIN, SONAR_TX_PIN);

  ledcSetup(0, 50, 16);  // 50 Hz, 16-bit - standard serwa
  ledcSetup(1, 50, 16);
  ledcAttachPin(PWM_THROTTLE_PIN, 0);
  ledcAttachPin(PWM_RUDDER_PIN, 1);
  applyOutputs();

  WiFi.softAP(AP_SSID, AP_PASS);
  udp.begin(UDP_IN_PORT);
  Serial.printf("AP: %s  IP: %s\n", AP_SSID, WiFi.softAPIP().toString().c_str());

  BLEDevice::init("TF650-BRIDGE");
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCB());
  BLEService* svc = server->createService(NUS_SERVICE_UUID);

  txChar = svc->createCharacteristic(NUS_TX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  txChar->addDescriptor(new BLE2902());

  BLECharacteristic* rxChar = svc->createCharacteristic(
      NUS_RX_UUID,
      BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  rxChar->setCallbacks(new RxCB());

  svc->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(NUS_SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

// ----------------------- LOOP -----------------------
void loop() {
  // 1) dane z sonaru -> telefon
  while (Serial2.available()) {
    char ch = Serial2.read();
    if (ch == '\n' || ch == '\r') {
      sonarLine.trim();
      if (sonarLine.length() > 5 && sonarLine[0] == '$' && checksumOk(sonarLine)) {
        broadcast(sonarLine);
      }
      sonarLine = "";
    } else {
      sonarLine += ch;
      if (sonarLine.length() > 512) sonarLine = "";
    }
  }

  // 2) komendy UDP z telefonu
  int sz = udp.parsePacket();
  if (sz > 0) {
    char buf[256];
    int n = udp.read(buf, sizeof(buf) - 1);
    if (n > 0) {
      buf[n] = 0;
      String s(buf);
      s.trim();
      handleCommand(s);
    }
  }

  // 3) failsafe - cisza z telefonu = stop
  if (millis() - lastCmdMs > FAILSAFE_MS && (throttlePct || rudderPct)) {
    throttlePct = 0;
    rudderPct = 0;
    applyOutputs();
  }
}
